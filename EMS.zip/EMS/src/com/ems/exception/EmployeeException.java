package com.ems.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3839568104363885313L;

	public EmployeeException(String message) {
		super(message);
		
	}
	
}
