package com.training.dao;

import java.util.List;

import com.training.bean.TraineeBean;
import com.training.exception.TraineeException;

public interface ITraineeDao {
	
	public int addTrainee(TraineeBean bean) throws TraineeException;
	
	/*public int deleteTrainee(int traineeId) throws TraineeException;
	
	public int modifyTrainee(int traineeId, TraineeBean bean) throws TraineeException;
	
	public List<TraineeBean> retrieveTrainee() throws TraineeException;
	
	public List<TraineeBean> retrievellTrainees() throws TraineeException;*/

}
