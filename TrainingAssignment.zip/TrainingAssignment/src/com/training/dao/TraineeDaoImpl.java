package com.training.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.training.bean.TraineeBean;
import com.training.exception.TraineeException;


@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		
		int id=0;
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			
			id=bean.getTraineeId();
		} catch (Exception e) {
			throw new TraineeException("Unable to persist" + e.getMessage());
		}
		
		return id;
	}

	/*@Override
	public int deleteTrainee(int traineeId) throws TraineeException {
		
		try {
			TraineeBean trn = entityManager.find(TraineeBean.class, traineeId);
			entityManager.remove(trn);
		} catch (Exception e) {
			throw new TraineeException("Unable to delete in dao " + e.getMessage());
		}
		
		return traineeId;
	}

	@Override
	public int modifyTrainee(int traineeId, TraineeBean bean)
			throws TraineeException {
		
		TraineeBean trn = entityManager.find(TraineeBean.class, traineeId);
		
		try {
			trn.setTraineeName(bean.getTraineeName());
			trn.setTraineeName(bean.getTraineeDomain());
			trn.setTraineeName(bean.getTraineeLocation());
			
			entityManager.merge(trn); //without merge update function still works
		} catch (Exception e) {
			throw new TraineeException(" could not update employee " + e.getMessage());
		}
		
		return traineeId;
	}

	@Override
	public List<TraineeBean> retrieveTrainee() throws TraineeException {
		
		return null;
	}

	@Override
	public List<TraineeBean> retrievellTrainees() throws TraineeException {
		
		List<TraineeBean>list=null;		
		try {
			TypedQuery<TraineeBean>query=entityManager.createQuery("Select t From TraineeBean t", TraineeBean.class);
			list = query.getResultList();
		} catch (Exception e) {
			throw new TraineeException(" Unable to fetch records in dao layer" + e.getMessage());
		}
		
		return null;
	}*/

}
