package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.bean.TraineeBean;
import com.training.dao.ITraineeDao;
import com.training.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	private ITraineeDao traineeDao;
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		
		
		return traineeDao.addTrainee(bean);
	}

}
