package com.training.exception;

public class TraineeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1531975439317228333L;

	public TraineeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
