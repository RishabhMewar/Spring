package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.training.bean.TraineeBean;
import com.training.exception.TraineeException;
import com.training.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;
	
	@RequestMapping("/showHomePage")
	public String showHomePage()
	{
		return("index1");
	}
	
	@RequestMapping(value="/addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trn") TraineeBean bean, BindingResult result)
	{
		ModelAndView modelAndView  = new ModelAndView();
		if(result.hasErrors())
		{
			modelAndView.setViewName("error");
			modelAndView.addObject("message","Binding failed");
		}
		else 
		{
			try {
				int id = traineeService.addTrainee(bean);
				modelAndView.setViewName("success");
				modelAndView.addObject("id",id);
				modelAndView.addObject("trn",bean);
			} catch (TraineeException e) {
				modelAndView.setViewName("error");
				modelAndView.addObject("message",e.getMessage());
			}
		}
		return(modelAndView);
	}

}


