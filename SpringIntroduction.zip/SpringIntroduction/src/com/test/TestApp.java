package com.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring2.xml");
		/*Triangle obj1 = (Triangle)ctx.getBean("triangle");
		obj1.draw();
		Triangle obj2 = (Triangle)ctx.getBean("triangle");
		obj2.draw();
		if (obj2==obj1)
		{
			System.out.println(" Singleton ");
		}
		else
		{
			System.out.println(" Prototype");
		}*/
		
		Triangle obj1 = (Triangle)ctx.getBean("triangle");
		obj1.draw();
		
		ctx.close();
		
		/*Triangle t = new Triangle();
		Point p = new.Point(); p.setX(10); p.setY(20;)*/
	

	}

}
