package com.igate.spel;

import java.util.ArrayList;

public class CityList {
	
	private ArrayList<City> cityList;
	private ArrayList<String> cityName;

	public ArrayList<String> getCityName() {
		return cityName;
	}

	public void setCityName(ArrayList<String> cityName) {
		this.cityName = cityName;
	}

	public ArrayList<City> getCityList() {
		return cityList;
	}

	public void setCityList(ArrayList<City> cityList) {
		this.cityList = cityList;
	}

}
