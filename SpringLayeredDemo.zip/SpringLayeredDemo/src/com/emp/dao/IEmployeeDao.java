package com.emp.dao;

import com.emp.bean.Employee;

public interface IEmployeeDao {
	
	//Takes parameter of employee. Add data to database
	//Here data can also be file so object should be serializable.
	public void addEmployee(Employee emp);
	

}
