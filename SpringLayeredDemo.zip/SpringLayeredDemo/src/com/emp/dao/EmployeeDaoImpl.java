package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.emp.bean.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {

	Map<Integer,Employee> map = new HashMap<Integer,Employee>();
	@Override
	public void addEmployee(Employee emp) {
		
		map.put(emp.getEmployeeId(),emp);
		
		

	}

}
