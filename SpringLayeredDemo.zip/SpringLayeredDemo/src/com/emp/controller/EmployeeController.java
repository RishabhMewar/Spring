package com.emp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.emp.bean.Employee;
import com.emp.service.IEmployeeService;

@Component
public class EmployeeController {
	
	@Autowired
	IEmployeeService employeeService;
	
	public void sendEmployee(Employee emp)
	{
		employeeService.addEmployee(emp);
	}
	

}
