package com.emp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.emp.bean.Employee;
import com.emp.controller.EmployeeController;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.emp")

public class TestApps {

	public static void main(String[] args) {
		ApplicationContext ctx= SpringApplication.run(TestApps.class, args);
		EmployeeController controller=(EmployeeController) ctx.getBean("employeeController");
		Employee emp=new Employee();
		emp.setEmployeeId(100);
		emp.setEmployeeName("John");
		controller.sendEmployee(emp);
		System.out.println("Emloyee added  successfully!!!!!!");
	}
}
