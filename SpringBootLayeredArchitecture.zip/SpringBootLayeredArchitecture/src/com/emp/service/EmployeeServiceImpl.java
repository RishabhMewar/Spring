package com.emp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.bean.Employee;
import com.emp.dao.IEmployeeDao;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
	

	@Autowired
	IEmployeeDao employeeDao;
	
	public IEmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(IEmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	@Override
	public void addEmployee(Employee emp) {
		
		employeeDao.addEmployee(emp);

	}

}
