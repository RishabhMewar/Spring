package com.emp.main;

public @interface EnableAutoConfiguration {

}
