package com.emp.service;

import com.emp.bean.Employee;
import com.emp.dao.IEmployeeDao;


public class EmployeeServiceImpl implements IEmployeeService {
	

	IEmployeeDao employeeDao;
	
	public IEmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(IEmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	@Override
	public void addEmployee(Employee emp) {
		
		employeeDao.addEmployee(emp);

	}

}
