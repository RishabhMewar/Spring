package com.emp.controller;

import com.emp.bean.Employee;
import com.emp.service.IEmployeeService;


public class EmployeeController {	
	
	IEmployeeService employeeService;
	
	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	public void sendEmployee(Employee emp){
		employeeService.addEmployee(emp);
	}
}
